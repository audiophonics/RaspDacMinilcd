#!/bin/sh
tar -xvzf rdmdac.tar.gz -C /usr/local/bin/
chmod +xX /usr/local/bin/apessq2m
node volumio_autoconf
exit 0
